#include <stdlib.h>
#include <stdio.h>
char *ft_strncpy(char *dest, const char *src, int n)
{
	int i = 0;
	while(src[i] && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return(dest);
}

int word_count(char *src)
{
	int i = 0;
	int wc = 0;
	while(src[i])
	{
		while(src[i] && (src[i] == ' ' || src[i] == '\t' || src[i] == '\n' ))
			i++;
		if(src[i])
			wc++;
		while(src[i] && src[i] != ' ' && src[i] != '\t' && src[i] != '\n')
			i++;
	}
	return(wc);
}

char    **ft_split(char *str)
{
	char **out = (char **)malloc(sizeof(char*) * (word_count(str) + 1));
	if(out == NULL)
		return(0);
	int i = 0;
	int one_word = 0;
	while(str[i])
	{
		while(str[i] && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n' ))
			i++;
		int start = i;
		while(str[i] && str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
			i++;
		if(i > start)
		{
			out[one_word] = (char *)malloc(sizeof(char) * (i - start) + 1);
			ft_strncpy(out[one_word], &str[start], i - start);
			one_word++;
		}
	}
	out[one_word] = NULL; 
	return(out);
}
/*
int main()
{
	printf("%i\n", word_count("t a b c "));
	printf("%s", ft_split("t a b c ")[0]);
}*/