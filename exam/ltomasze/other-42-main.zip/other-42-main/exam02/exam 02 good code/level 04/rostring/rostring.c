#include<unistd.h>

void putfirstword(char *str)
{
	int i = 0;
	while(str[i] == ' ' || str[i] == '\t')
		i++;
	while(str[i] != ' ' && str[i] != '\t' && str[i] != '\0')
	{
		write(1, &str[i], 1);
		i++;
	}
}
	

int main(int ac, char **av)
{
	if(ac > 1)
	{
		int i = 0;
		while(av[1][i] == ' ' || av[1][i] == '\t')
			i++;
		while(av[1][i] != ' ' && av[1][i] != '\t' && av[1][i] != '\0')
			i++;
		while(av[1][i] == ' ' || av[1][i] == '\t')
			i++;
		if(av[1][i] != '\0')
		{
			while(av[1][i] != '\0')
			{
				if(av[1][i] == ' ' || av[1][i] == '\t')
				{
					while(av[1][i] == ' ' || av[1][i] == '\t')
						i++;
					if(av[1][i] != '\0')
						write(1, " ", 1);
				}
				else
				{
					write(1, &av[1][i], 1);
						i++;
				}
			}
			write(1, " ", 1);
		}
		putfirstword(av[1]);
	}
	write(1, "\n", 1);
}