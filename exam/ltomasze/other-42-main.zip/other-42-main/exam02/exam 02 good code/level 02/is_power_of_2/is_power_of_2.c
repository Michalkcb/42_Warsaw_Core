int	    is_power_of_2(unsigned int n)
{
	unsigned int i = 0;

	if(n == 1)
		return (1);
	if(n >= 2)
	{
		while(i < n)
		{
			if(i * 2 == n)
				return (1);
			i++;
		}
	}
	return (0);
}
/*
#include <stdio.h>
int main()
{
	unsigned int n = 1024;
	printf("%i\n", is_power_of_2(n));
}*/