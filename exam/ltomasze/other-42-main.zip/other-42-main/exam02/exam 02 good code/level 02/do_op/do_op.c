#include<stdlib.h>
#include<unistd.h>
#include<stdio.h>

int main(int ac, char **av)
{
	if(ac == 4)
	{
		int nb1 = atoi(av[1]);
		int nb2 = atoi(av[3]);
		int res = 0;
		if(av[2][0] == '*')
		{
			res = nb1*nb2;
			printf("%i", res);
		}
		if(av[2][0] == '/')
		{
			res = nb1/nb2;
			printf("%i", res);
		}
		if(av[2][0] == '+')
		{
			res = nb1+nb2;
			printf("%i", res);
		}
		if(av[2][0] == '-')
		{
			res = nb1-nb2;
			printf("%i", res);
		}
		if(av[2][0] == '%')
		{
			res = nb1%nb2;
			printf("%i", res);
		}
	}
	printf("\n");
	return(0);
}