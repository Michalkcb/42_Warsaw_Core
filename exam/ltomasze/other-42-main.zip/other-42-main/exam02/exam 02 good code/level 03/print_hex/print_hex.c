#include<unistd.h>

void puthex(int nbr)
{
	if(nbr > 15)
		puthex(nbr / 16);
	write(1, &"0123456789abcdef"[nbr % 16], 1);
}

int ft_atoi(const char *nptr)
{
	int i = 0;
	int res = 0;
	while(nptr[i] >= '0' && nptr[i] <= '9' && nptr[i] != '\0')
	{
			res = res * 10 + nptr[i] - 48;
			i++;
	}
	return(res);
}

int main(int ac, char **av)
{
	if (ac == 2)
	{
		int nbr = ft_atoi(av[1]);
		puthex(nbr);
	}
	write(1, "\n", 1);
	return(0);
}