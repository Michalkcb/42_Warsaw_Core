#include<unistd.h>

void putstr(char *str)
{
	int i = 0;
	while(str[i])
	{
		if(str[0] >= 'a' && str[0] <= 'z')
		{
			str[0] = str[0] - 32;
			write(1, &str[0], 1);
		}
		else if((str[i - 1] == ' ' || str[i - 1] == '\t') && (str[i] >= 'a' && str[i] <= 'z'))
		{
			str[i] = str[i] - 32;
			write(1, &str[i], 1);
		}
		else if(((str[i - 1] >= 'A' && str[i - 1] <= 'Z') || (str[i - 1] == '_') || (str[i - 1] >= 'a' && str[i - 1] <= 'z')) && (str[i] >= 'A' && str[i] <= 'Z'))
		{
			str[i] = str[i] + 32;
			write(1, &str[i], 1);
		}
		else
			write(1, &str[i], 1);
		i++;
	}
}

int main(int ac, char **av)
{
	if(ac > 1)
	{
		int i = 1;
		while(av[i] != NULL)
		{
			putstr(av[i]);
			write(1, "\n,", 1);
			i++;
		}
	}
	else
		write(1, "\n,", 1);
	return(0);
}