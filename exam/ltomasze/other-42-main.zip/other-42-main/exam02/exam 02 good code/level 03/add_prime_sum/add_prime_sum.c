#include<unistd.h>

int ft_atoi(const char *nptr)
{
	int i = 0;
	int res = 0;
	int sign = 1;
	if(nptr[i] == '-')
	{
		sign = -1;
		i++;
	}
	while(nptr[i] >= '0' && nptr[i] <= '9')
	{
		res = res * 10 + nptr[i] - 48;
		i++;
	}
	return(res * sign);
}

int ifprime(int n)
{
	int i = 2;
	if( n == 1)
		return (0);
	while(i < n)
	{
		if(n % i == 0)
			return(0);
		i++;
	}
	return (1);
}

void putnbr(int nbr)
{
	if(nbr > 9)
		putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int main(int ac, char **av)
{
	if(ac == 2)
	{
		int n = ft_atoi(av[1]);
		int sum = 0;
		while(n > 0)
		{
			if(ifprime(n) == 1)
				sum = sum + n;
			n--;
		}
		putnbr(sum);
		write(1, "\n", 1);
	}
	else
		write(1, "0\n", 2);
	return(0);
}