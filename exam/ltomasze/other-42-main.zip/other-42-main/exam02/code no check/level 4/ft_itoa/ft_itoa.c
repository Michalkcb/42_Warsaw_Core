int len_nbr(long nbr)
{
	int len = 0;
	if(nbr == 0)
		return(1);
	if(nbr < 0)
		len++;
	while(nbr != 0)
	{
		nbr = nbr / 10;
		len++;
	}
	return(len);
}

#include <stddef.h>
#include <stdlib.h>
char	*ft_itoa(int nbr)
{
	int len;
	len = len_nbr(nbr);
	char *res;
	res = (char *)malloc(sizeof(char) * len + 1);
	if(res == NULL)
		return (NULL);
	res[len] = '\0';
	long nb = nbr;
	if(nb == 0)
	{
		res[0] = '0';
		return(res);
	}
	if(nb < 0)
	{
		res[0] = '-';
		nb = -nb; 
	}
	len = len - 1;
	while(nb)
	{
		res[len] = nb % 10 + '0';
		nb = nb / 10;
		len--;
	}
	return(res);
}

#include<stdio.h>
int main()
{
	long nbr = -2147483648;
	printf("%s\n", ft_itoa(nbr));
}