#include <stdlib.h>
// do kopiowania słowa do tablicy dla jednego słowa
char *ft_strncpy(char *s1, char *s2, int n)
{
	int i = 0;
	while (i < n && s2[i])
	{
		s1[i] = s2[i];
		i++;
	}
	s1[i] = '\0';
	return(s1);
}
char    **ft_split(char *str)
{
	int i = 0;
	int start_word = 0;
	int one_word = 0;
	int count_words = 0;
	//cześć funkcji odpowiadająca za liczenie ilości słow
	while(str[i] != '\0')
	{
		while(str[i] != '\0' && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'))
			i++;
		if(str[i])
			count_words++;
		while(str[i] != '\0' && str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
			i++;
	}
	//użycie malloca w celu przygotowania tablicy tablic, czyli
	// tablicy dla ilości słów, dlatego **
	char **out = (char **)malloc(sizeof(char *) *(count_words + 1));
	//część funkcji do liczenia długości słowa
	i = 0;
	while(str[i] != '\0')
	{
		while (str[i] && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'))
			i++;
		start_word = i;
		while(str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
			i++;
		//użycie malloca do stworzenia tablicy dla jednego słowa, ,która to tablica
		//mieści się w tablicy liczącej ilość słów
		if(i > start_word)
		{
			out[one_word] = (char *)malloc(sizeof(char) * (i - start_word) + 1);
			//funkcja do kopiowania słowa do tablicy i tak co słowo
			ft_strncpy(out[one_word], &str[start_word], i - start_word);
			one_word++;
		}
	}
	//null na koniec tablicy zliczającej ilość 
	out[one_word] = NULL;
	return (out);
}
/*
#include<stdio.h>
int main()
{
	printf("%s", ft_split("Hello World")[1]);
	printf("\n%c", "slowo"[1]);
}*/