#include <stdio.h>
#include <stdlib.h>

int main(int ac, char **av)
{
	if(ac == 2)
	{
		int nbr = atoi(av[1]);
		int i = 2;
		if(nbr == 1)
		{
			printf("1");
			printf("\n");
			return (0);
		}
		while(nbr >= i)
		{
			if(nbr % i == 0)
			{
				printf("%i", i);
				if (nbr == i)
					break;
				printf("*");
				nbr = nbr / i;
				i = 2;
			}
			i++;
		}

	}
	printf("\n");
	return (0);
}