#include "list.h"
t_list	*sort_list(t_list* lst, int (*cmp)(int, int))
{
	t_list *current;
	t_list *backup;
	int tmp;
	backup = lst;
	while(backup->next)
	{
		current = lst;
		while(current->data && current->next)
		{
			if((*cmp)(current->data, current->next->data) == 0)
			{
				tmp = current->data;
				current->data = current->next->data;
				current->next->data = tmp;
			}
			current = current->next;
		}
		backup = backup->next;
	}
	return(lst);
}
/*
#include<stdio.h>

int cmp(int a, int b)
{
	return(a - b);
}

int main()
{
	t_list node3 = {2, NULL};
	t_list node2 = {1, &node3};
	t_list node1 = {8, &node2};
	node1 = *sort_list(&node1, *cmp);
	printf("%i %i %i\n", node1.data, node2.data, node3.data);
}*/