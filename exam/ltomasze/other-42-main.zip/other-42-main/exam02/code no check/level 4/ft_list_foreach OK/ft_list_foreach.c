#include "ft_list.h"
#include <stddef.h>

void    ft_list_foreach(t_list *begin_list, void (*f)(void *))
{
	while(begin_list != NULL)
	{
		(*f)(begin_list->data);
		begin_list = begin_list->next;
	}
}

#include <stdio.h>

void print_data(void *data)
{
    printf("%s\n", (char *)data);
}

int main()
{
    t_list node3 = {NULL, "C"};
    t_list node2 = {&node3, "B"};
    t_list node1 = {&node2, ""};

    ft_list_foreach(&node1, print_data);

    return 0;
}
