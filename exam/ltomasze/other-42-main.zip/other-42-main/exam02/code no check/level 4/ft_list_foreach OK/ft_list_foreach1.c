#include "ft_list.h"
#include <stddef.h>

void    ft_list_foreach(t_list *begin_list, void (*f)(void *))
{
	while(begin_list /*!= NULL*/)
	{
		(*f)(begin_list->data);
		begin_list = begin_list->next;
	}
}

#include <stdio.h>

void print_data(void *data)
	{
		printf("%s\n", (char *)data);
	}

int main()
{
	t_list data3 = {NULL, "C"};
	t_list data2 = {&data3, "B"};
	t_list data1 = {&data2, "A"};

	
	ft_list_foreach(&data1, print_data);
}