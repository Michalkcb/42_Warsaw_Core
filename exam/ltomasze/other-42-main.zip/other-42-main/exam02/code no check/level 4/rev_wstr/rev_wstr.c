#include<unistd.h>
int main(int ac, char **av)
{
	if(ac == 2)
	{
		int i = 0;
		while(av[1][i] != '\0')
			i++;
		i = i - 1;
		while( i >= 0)
		{
			i--;
			if(av[1][i] == ' ')
			{
				int j = i + 1;
				while(av[1][j] != ' ' && av[1][j] != '\0')
				{
					write(1, &av[1][j], 1);
					j++;
				}
				write(1, " ", 1);
			}
			else if (i == 0)
			{
				int j = i;
				while(av[1][j] != ' ' && av[1][j] != '\0')
				{
					write(1, &av[1][j], 1);
					j++;
				}
			}
		}
	}
	write(1, "\n", 1);
	return(0);
}