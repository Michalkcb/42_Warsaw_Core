/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/17 14:39:59 by ltomasze          #+#    #+#             */
/*   Updated: 2024/04/17 14:48:38 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] && str[i] != '\0')
		i++;
	return (i);
}

#include <stdio.h>

int	main()
{
	char str[] = "Hello_World";
	printf("%s\n", str);
	printf("%d", ft_strlen(str));
}
	
