/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/17 15:06:35 by ltomasze          #+#    #+#             */
/*   Updated: 2024/04/17 15:32:32 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int temp;

	temp= *a;
	*a = *b;
	*b = temp;
}

#include <stdio.h>

int	main()
{
	int a = 23;
	int b = 44;

	printf("a = %d" "b = %d\n", a, b);
	ft_swap(&a, &b);
	printf("a swap = %d" "b swap = %d", a, b);
	return(0);
}
