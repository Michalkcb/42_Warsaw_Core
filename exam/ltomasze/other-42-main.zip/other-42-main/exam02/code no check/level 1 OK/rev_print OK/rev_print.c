/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rev_print.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/19 11:36:15 by ltomasze          #+#    #+#             */
/*   Updated: 2024/04/19 14:36:09 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <string.h>

int	ft_strlen(char *s)
{
	int	i;

	i = 0;
	while(s[i] != '\0')
		i++;
	return(i);
}

int	main(int ac, char **av)
{
	int	j;

	{
		if(ac == 2)
		{
			j = ft_strlen(&av[1][j]) - 1;
			while(j >= 0)
			{
				write(1, &av[1][j], 1);
				j--;
			}
			write(1, "\n", 1);
		}
		else
			write(1, "\n", 1);	
	}
	return (0);
}

