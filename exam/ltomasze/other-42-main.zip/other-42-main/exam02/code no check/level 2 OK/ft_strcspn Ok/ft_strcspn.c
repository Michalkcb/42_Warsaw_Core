/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcspn.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/24 15:02:23 by ltomasze          #+#    #+#             */
/*   Updated: 2024/04/24 17:27:04 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

size_t	ft_strcspn(const char *s, const char *reject)
{
	size_t	i;
	size_t	j;

	i = 0;
	while(s[i] != '\0')
	{
		j = 0;
		while(reject[j] != '\0')
		{
			if(s[i] == reject[j])
				return (i);
			j++;
		}	
		i++;
	}
	return(i);
}

int	main()
{
	char *s = "Hello";
	char *reject = "jp";
	printf("the same character is in position %zu\n", ft_strcspn(s, reject));
	printf("the same character is in position %zu\n", strcspn(s, reject));
	return (0);
}
