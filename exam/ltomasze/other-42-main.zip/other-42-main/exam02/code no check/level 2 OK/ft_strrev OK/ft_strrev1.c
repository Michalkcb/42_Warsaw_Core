#include <stdio.h>

char    *ft_strrev(char *str)
{
	int	i;
	int	len;
	char temp;

	len = 0;
	while(str[len])
		len++;
	i = 0;
	if(i < len - 1)
	{
		temp = str[len - 1];
		str[len - 1] = str[i];
		str[i] = temp;
		i++;
		len--;
	}
	return(str);	
}

int	main(void)
{
	char	str[] = "Hello";
	printf("%s\n", ft_strrev(str));
	printf("%s\n", str);
	return (0);
}