#include <stdlib.h>

char    *ft_strdup(char *src)
{
	char	*temp;
	int	len;
	int	i;

	len = 0;
	while(src[len] != '\0')
		len++;
	temp = 0;
	temp = malloc(sizeof(char) * len + 1);
	if(temp == NULL)
		return(NULL);
	i = 0;
	while(src[i] != '\0' && i < len)
	{
		temp[i] = src[i]
		i++;
	}
	temp[i] = '\0';
	return(temp);
}
