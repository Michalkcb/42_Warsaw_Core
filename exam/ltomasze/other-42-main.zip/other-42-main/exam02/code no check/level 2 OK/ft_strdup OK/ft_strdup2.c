#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char    *ft_strdup(char *src)
{
	int	i;
	int len;
	char *temp;

	len = 0;
	while(src[len] != '\0')
		len++;
	temp = (char *)malloc(sizeof(char) * len + 1);
	if (temp == NULL)
		return(NULL);
	i = 0;
	while(src[i] != '\0' && i < len)
	{
		temp[i] = src[i];
		i++;
	}
	temp[i] = '\0';
	return(temp);
}

int	main()
{
	char src[] = "Hello";
	printf("%s\n", strdup(src));
	printf("%s\n", ft_strdup(src));
}