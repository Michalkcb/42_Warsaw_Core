#include <stdio.h>

int		max(int* tab, unsigned int len)
{
	int	i;
	int m;

	i = 0;
	m = tab[i];
	if(len == 0)
		return(0);
	while(tab[i])
	{
		if( i > m)
			m = tab[i];
		i++;
	}
	return(m);
}

int	main()
{
	int	tab[] = {1, 2, 5, 3, 4};
	unsigned int	len = 5;
	printf("%d\n", max(tab, 5));
}