#include <stdio.h>

int		max(int* tab, unsigned int len)
{
	int	i;
	char	m;

	i = 0;
	m = 0;
	while(tab[i] && i < len)
	{
		if(tab[i] > m)
			m = tab[i];
		i++;
	}
	return(m);
}

int	main()
{
	int tab[] = {8, 2, 5, 3, 7};
	int len = 5;
	printf("%d\n", max(tab, 5));
}