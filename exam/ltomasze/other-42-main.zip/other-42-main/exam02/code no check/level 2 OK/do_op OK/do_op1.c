/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_op1.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/23 11:01:23 by ltomasze          #+#    #+#             */
/*   Updated: 2024/04/23 11:54:36 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	main(int ac, char **av)
{
	{
		if(ac == 4)
		{
			while(av[2][0])
			{
				if(av[2][0] == '+')
				{
					printf("%d", (atoi(av[1]) + atoi(av[3])));
					break;
				}
				else if(av[2][0] == '-')
				{
                                	printf("%d", (atoi(av[1]) - atoi(av[3])));
                                	break;
                        	}
				else if(av[2][0] == '*')
                        	{
                                	printf("%d", (atoi(av[1]) * atoi(av[3])));
                                	break;
                        	}
				else if(av[2][0] == '/')
                        	{
                                	printf("%d", (atoi(av[1]) / atoi(av[3])));
                                	break;
                        	}
				else if(av[2][0] == '%')
                        	{
                        		printf("%d", (atoi(av[1]) + atoi(av[3])));
                                	break;
                        	}
			}
		}
		printf("\n");
	}
	return (0);
}
