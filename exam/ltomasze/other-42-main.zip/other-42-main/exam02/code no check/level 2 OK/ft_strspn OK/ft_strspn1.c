#include <stdio.h>
#include <string.h>

size_t ft_strspn(const char *s, const char *accept)
{
	int	i;
	int	j;
	char check;

	i = 0;
	while(s[i] != '\0')
	{
		j = 0;
		check = 0;
		while(accept[j] != '\0' && check != 1)
		{
			if(s[i] == accept[j])
				check = 1;
			j++;
		}
		if (check == 0)
		return(i);
		i++;
	}
	return(i);
}

int	main()
{
	char	*s = "Helao";
	char	*accept = "Hello";
	printf("%lu\n", ft_strspn(s, accept));
	printf("%lu\n", strspn(s, accept));
}