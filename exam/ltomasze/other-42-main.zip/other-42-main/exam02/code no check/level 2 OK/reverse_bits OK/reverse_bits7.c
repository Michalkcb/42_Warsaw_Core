unsigned char	reverse_bits(unsigned char octet)
{
	int i = 8;
	unsigned char rev = 0;
	while(i--)
	{
		rev = (rev << 1) | (octet & 1);
		octet = octet >> 1;
	}
}

#include <stdio.h>
int main()
{
	int i = 8;
	unsigned char bit = 0;
	unsigned char rev = reverse_bits(2);
	while(i--)
	{
		bit = (rev >> i & 1) + 48;
		printf("%c", bit);
	}
}