unsigned char	reverse_bits(unsigned char octet)
{
	unsigned char	rev;
	int	i;

	i = 8;
	while(i--)
	{
		rev = (rev << 1) | (octet & 1);
		octet = octet >> 1;
	}
	return (rev);
}

#include <stdio.h>

int	main(void)
{
	int i;
	unsigned char	bit;
	unsigned char	res;

	i = 8;
	bit = 0;
	res = reverse_bits(5);
	while(i--)
	{
		bit = (res >> i & 1) + 48;
		printf("%c", bit);
	}
}
