unsigned char	reverse_bits(unsigned char octet)
{
	unsigned int rev = 0;
	int i = 8;
	while(i--)
	{
		rev = (rev << 1) | (octet & 1);
		octet = octet >> 1;
	}
	return(rev);
}