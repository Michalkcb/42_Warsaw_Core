#include <unistd.h>
#include <stdio.h>
unsigned char	reverse_bits(unsigned char octet)
{
	int	i;
	unsigned char	rev;
	
	i = 8;
	while(i--)
	{
		rev = (rev << 1) | (octet & 1);
		octet = octet >> 1;
	}
	return (rev);
}

int main(void)
{
	unsigned char	bit = 0;
	unsigned char	rev = reverse_bits(5);

	int	i;

	i = 8;
	while(i--)
	{
		bit = (rev >> i & 1) + 48;
		write(1, &bit, 1);
	}
}