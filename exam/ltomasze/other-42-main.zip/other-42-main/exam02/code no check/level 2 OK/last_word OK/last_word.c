#include <unistd.h>
#include <stdio.h>

int	main(int ac, char **av)
{
	int	i;

	if(ac == 2)
	{
		while(av[1][i] != '\0')
			i++;
		printf("1 = %d\n", i);
		i--;
		printf("2 = %d\n", i);
		while(av[1][i] <= 32)
			i--;
		printf("3 = %d\n", i);
		while(av[1][i] > 32)
                        i--;
		printf("4 = %d\n", i);
		i++;
		printf("5 = %d\n", i);
		while(av[1][i] > 32)
		{
			write(1, &av[1][i], 1);
			i++;
		}
	}
	write(1, "\n", 1);
	return (0);
}
