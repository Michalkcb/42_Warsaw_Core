#include <string.h>
#include <stdio.h>

char	*ft_strpbrk(const char *s1, const char *s2)
{
	int	j;

	while(*s1 != '\0')
	{
		j = 0;
		while(s2[j] != '\0')
		{
			if(s2[j] == *s1)
				return((char *)s1);
			j++;
		}
		s1++;
	}
	return(NULL);
}

int	main()
{
	char *s1 = "Hello_World$";
	char *s2 = "katl!";
	printf("%s\n", strpbrk(s1, s2));
	printf("%s\n", ft_strpbrk(s1, s2));
}
