#include <string.h>
#include <stdio.h>

char	*ft_strpbrk(const char *s1, const char *s2)
{
	int	i;
	int j;
	char	*res;

	i = 0;
	res = (char *)s1;
	while(res[i] != '\0')
	{
		j = 0;
		while(s2[j] != '\0')
		{
			if(res[i] == s2[j])
				return (&res[i]);
			j++;
		}
		i++;
	}
	return (NULL);	
}

int	main()
{
	char *s1 = "Hello World!";
	char *s2 = "akjr";
	printf("strpbrk = %s\n", strpbrk(s1, s2));
	printf("ft_strpbrk = %s\n", ft_strpbrk(s1, s2));
}