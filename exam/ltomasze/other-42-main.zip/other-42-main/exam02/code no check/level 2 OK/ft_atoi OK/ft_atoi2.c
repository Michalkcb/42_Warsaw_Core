/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/23 16:29:43 by ltomasze          #+#    #+#             */
/*   Updated: 2024/04/23 16:56:35 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_atoi(const char *str)
{
	int	sign;
	int	nbr;

	sign = 1;
	nbr = 0;
	while((*str >= 9 && *str <= 13) || *str == ' ')
		str++;
	if(*str == '-')
	{
		sign = -1;
		str++;
	}
	while(*str >= '0' && *str <= '9')
	{
		nbr = nbr * 10 + *str - 48;
		str++;
	}
	return (nbr * sign);
}

int	main()
{
	char str[15] = "   -0123456789";
	printf("%d\n", ft_atoi(str));
	return(0);
}


