/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <ltomasze@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/22 16:28:21 by ltomasze          #+#    #+#             */
/*   Updated: 2024/05/14 09:45:26 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_atoi(const char *str)
{
	int	i;
	int	sign;
	int	result;

	i = 0;
	while(str[i] != '\0')
	{
		if((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
			i++;
		else if(str[i] == '-')
		{
			sign = -1;
			i++;
		}
		else if(str[i] >= '0' && str[i] <= '9')
		{
			result = (result * 10) + str[i] - 48;
			i++;
		}
	}
	return (result * sign);
}
