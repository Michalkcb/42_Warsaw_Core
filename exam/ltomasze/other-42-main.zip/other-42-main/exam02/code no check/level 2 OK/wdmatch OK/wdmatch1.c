#include <unistd.h>
#include <stdio.h>

int	main(int ac, char **av)
{
	int	i;
	int	j;
	int	k;
	int	len;

	i = 0;
	j = 0;
	if(ac == 3)
	{
		len = 0;
		while(av[1][len] != '\0')
			len++;
		i = 0;
		j = 0;
		while(av[2][j] != '\0')
		{
			if(av[2][j] == av[1][i])
				i++;
			j++;
		}
		if(i == len)
			write(1, av[1], len);
	}
	write(1, "\n", 1);
	return (0);
}
