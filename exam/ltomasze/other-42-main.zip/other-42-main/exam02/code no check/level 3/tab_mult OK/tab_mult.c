#include <unistd.h>

int ft_atoi(const char *nptr)
{
	int	i = 0;
	int result = 0;
	while(nptr[i] != '\0')
	{
		if(nptr[i] >= '0' && nptr[i] <= '9')
			result = result * 10 + nptr[i] - 48;
			i++;
	}
	return(result);
}

/*void ft_putchar(int i)
{
	char c = (char *)i;
	write(1, &c, 1);
}*/

void ft_putnbr(int n)
{
	if (n > 9)
		ft_putnbr(n / 10);
	write(1, &"0123456789"[n % 10], 1);
}

int	main(int ac, char **av)
{
	int i;
	int nbr = 0;

	if(ac == 2)
	{
		i = 1;
		nbr = ft_atoi(av[1]);
		while(i < 10)
		{
			ft_putnbr(i);
			write(1," x ", 3);
			ft_putnbr(nbr);
			write(1, " = ", 3);
			ft_putnbr(i * nbr);
			write(1, "\n", 1);
			i++;
		}
	}
	else
		write(1, "\n", 1);
	return (0);
}