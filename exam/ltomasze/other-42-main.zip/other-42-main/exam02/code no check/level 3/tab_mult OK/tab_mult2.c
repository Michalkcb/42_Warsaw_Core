#include <unistd.h>

int ft_atoi(char *nptr)
{
	int	i = 0;
	int	res = 0;
	while(nptr[i] != '\0')
	{
		if(nptr[i] >= '0' && nptr[i] <= '9')
			res = res * 10 + nptr[i] - 48;
		i++;
	}
	return (res);
}

void ft_putnbr(int nbr)
{
	if(nbr > 9)
		ft_putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int	main(int ac, char **av)
{
	if(ac == 2)
	{
		int i = 1;
		int n = ft_atoi(av[1]);
		while(i <= 9)
		{
			ft_putnbr(i);
			write(1, " x ", 3);
			ft_putnbr(n);
			write(1, " = ", 3);
			ft_putnbr(n * i);
			write(1, "\n", 1);
			i++;
		}
	}
	else
		write(1, "\n", 1);
	return (0);
}
/*
#include <stdio.h>
int main()
{
	char *nptr = "5";
	printf("%d\n", ft_atoi(nptr));
	int	nbr = 10;
	printf("%d\n", ft_putnbr(nbr));
}
*/