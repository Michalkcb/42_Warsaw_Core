#include <unistd.h>

void	ft_putnbr(int nbr)
{
	if(nbr > 9)
		ft_putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int	ft_atoi(const char *nptr)
{
	int	res;
	int	i;

	res = 0;
	i = 0;
	while(nptr[i] != '\0')
	{
		if(nptr[i] >= '0' && nptr[i] <= '9')
			res = res * 10 + nptr[i] - 48;
			i++;
	}
	return (res);
}

int	main(int ac, char **av)
{
	int	i;
	char nb;

	
	if(ac == 2)
	{
		nb = ft_atoi(av[1]);
		i = 1;
		while(i <= 9)
		{
			ft_putnbr(i);
			write(1, " x ", 3);
			ft_putnbr(nb);
			write(1, " = ", 3);
			ft_putnbr(nb * i);
			write(1, "\n", 1);
			i++;
		}
	}
	else
		write(1, "\n", 1);
	return (0);
}