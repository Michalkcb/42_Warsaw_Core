#include<unistd.h>

int ft_atoi(char *nptr)
{
	int i = 0;
	int res = 0;
	while(nptr[i])
	{
		if(nptr[i] >= '0' && nptr[i] <= '9')
		res = res * 10 + nptr[i] - 48;
		i++;
	}
	return (res);
}

void putnbr(int nbr)
{
	if(nbr > 9)
		putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int main (int ac, char **av)
{
	if(ac == 2)
	{
		int n = ft_atoi(av[1]);
		int i = 1;
		while(i < 10)
		{
			putnbr(i);
			write(1, " x ", 3);
			putnbr(n);
			write(1, " = ", 3);
			putnbr(n * i);
			write(1, "\n", 1);
			i++;
		}	
	}
	else
		write(1, "\n", 1);
	return (0);
}