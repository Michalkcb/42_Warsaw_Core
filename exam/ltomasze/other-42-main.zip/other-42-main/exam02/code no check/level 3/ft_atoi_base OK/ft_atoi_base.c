#include <unistd.h>
#include <stdio.h>
int is_in_base(char c, int base)
{
	return ((c >= '0' && c <= '0' + base - 1) || (c >= 'a' && c <= 'a' + base - 11) || \
		(c >= 'A' && c <= 'A' + base - 11));
}
int	ft_atoi_base(const char *str, int str_base)
{
	int i = 0;
	int sign = 1;
	int nbr = 0;
	while((str[i] == ' ' || (str[i] >= 9 && str[i] <= 13 )) && str[i])
		i++;
	if(str[i] == '-' && i == 0)
		sign = -1;
	if(str[i] == '-' || str[i] == '+')
		i++;
	while(is_in_base(str[i], str_base) && str[i])
	{
		if(str[i] >= '0' && str[i] <= '9')
			nbr = nbr * str_base + str[i] - '0';
		else if (str[i] >= 'A' && str[i] <= 'F')
			nbr = nbr *str_base + str[i] - 'A' + 10;
		else if (str[i] >= 'a' && str[i] <= 'f')
			nbr = nbr *str_base + str[i] - 'a' + 10;
		i++;
	}
	return nbr;
}
int main()
{
	int base = 12;
	char *str = "1b1";
	printf("%d\n", ft_atoi_base(str, base));
	return 0;
}













