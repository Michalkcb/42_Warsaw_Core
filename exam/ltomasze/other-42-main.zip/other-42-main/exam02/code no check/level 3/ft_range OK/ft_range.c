#include<stddef.h>
#include<stdlib.h>
int	ft_abs(int nbr)
{
	if (nbr < 0)
		return (-nbr);
	return (nbr);
}
int     *ft_range(int start, int end)
{
	int *tab = 0;
	int len = 0;
	int i = 0;
	if(start > end)
	{
		len = ft_abs(start - end);
		tab = (int *)malloc(sizeof(int) * len + 1);
	}
	else
	{
		len = ft_abs(end - start);
		tab = (int *)malloc(sizeof(int) * len + 1);
	}
	if(tab == NULL)
		return(0);
	tab[i] = 0;
	while (start <= end)
	{
		tab[i] = start;
		start++;
		i++;
	}
	tab[i] = 0;
	while(start >= end)
	{
		tab[i] = start;
		i++;
		start--;
	}
	return(tab);	
}

#include <stdio.h>

int	main(void)
{
	int	*tab;
	int	i = 0;
	int	start = 0;
	int	end = -3;
	int	len;

	tab = ft_range(start, end);
	len = ft_abs(end - start) + 1;
	while (i < len)
	{
		printf(" [%i] ", tab[i]);
		i++;
	}
	printf("\n");
}