#include <stdlib.h>
int ft_abs(int nbr)
{
	if(nbr < 0)
		return (-nbr);
	return (nbr);
}

int     *ft_range(int start, int end)
{
	int len = 0;
	int *tab = 0;
	if(start < end)
	{
		len = ft_abs(end - start);
		tab = (int *)malloc(sizeof(int) * len + 1);
	}
	else
	{
		len = ft_abs(start - end);
		tab = (int *)malloc(sizeof(int) * len + 1);
	}
	if(tab == NULL)
		return(0);
	int i = 0;
	tab[i] = start;
	while(start <= end)
		tab[i++] = start++;
	tab[i] = start;
	while(start >= end)
		tab[i++] = start--;
	return(tab);
}

#include<stdio.h>
int main()
{
	int i = 0;
	int end = -3;
	int start = 0;
	int len = ft_abs(start - end) + 1;
	int *tab;
	tab = ft_range(start, end);
	while( i < len)
	{
		printf(" [%i] ", tab[i]);
		i++;
	}
	printf("\n");
}