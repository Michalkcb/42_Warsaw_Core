#include<unistd.h>

int ft_atoi(char *nptr)
{
	int	i = 0;
	int res = 0;
	while(nptr[i] >= '0' && nptr[i] <= '9')
	{
		res = res * 10 + nptr[i] - 48;
		i++;
	}
	return (res);
}

void puthex(int hex)
{
	if(hex >= 16)
		puthex(hex / 16);
	write(1, &"0123456789abcdef"[hex % 16], 1);
}

int main(int ac, char **av)
{
	if(ac == 2)
		puthex(ft_atoi(av[1]));
	write(1, "\n", 1);
}