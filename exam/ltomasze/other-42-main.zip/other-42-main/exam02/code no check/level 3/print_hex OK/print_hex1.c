#include <unistd.h>

void puthex(int hex)
{
	if(hex > 15)
		puthex(hex / 16);
	write(1, &"0123456789abcdef"[hex % 16], 1);
}

int ft_atoi(char *nptr)
{
	int i = 0;
	int res = 0;
	while(nptr[i] != '\0')
	{
		res = res * 10 + nptr[i] - 48;
		i++;
	}
	return (res);
}

int main(int ac, char **av)
{
	if(ac == 2)
	{
		int n = ft_atoi(av[1]);
		puthex(n);
	}
	write(1, "\n", 1);
	return(0);		
}

/*
#include<stdio.h>
int main()
{
	int hex = 255;
	char *nptr = "255";
	puthex(hex);
	printf("\n");
	printf("%d\n", ft_atoi(nptr));
}
*/