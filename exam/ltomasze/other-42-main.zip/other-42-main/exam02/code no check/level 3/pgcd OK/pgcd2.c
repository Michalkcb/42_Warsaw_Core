#include<stdio.h>
#include<stdlib.h>

int main(int ac, char **av)
{
	
	if(ac == 3)
	{
		int p1 = atoi(av[1]);
		int p2 = atoi(av[2]);

		if(p1 > 0 && p2 > 0)
		{
			while(p1 != p2)
			{
				if(p1 > p2)
					p1 = p1 - p2;
				else
					p2 = p2 - p1;
			}
		}
		printf("%i", p1);
	}
	printf("\n");
	return(0);
}