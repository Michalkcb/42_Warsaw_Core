#include<unistd.h>
#include<stdio.h>

int	main(int ac, char **av)
{
	if(ac == 2 && av[1][0] != '\0')
	{
		int i = 0;
		char *str = av[1];
		while((str[i] == 32 || str[i] == 9) && str[i] != '\0')
			i++;
		while(str[i] != '\0')
		{
			while(str[i] != 32 && str[i] != 9 && str[i] != '\0')
			{
				write(1, &str[i], 1);
				i++;
			}
			while((str[i] == 32 || str[i] == 9) && av[1][i] != '\0')	
				i++;
			if(str[i] != '\0')
				write(1, "...", 3);
		}
	}
	write(1, "\n", 1);
	return(0);
}