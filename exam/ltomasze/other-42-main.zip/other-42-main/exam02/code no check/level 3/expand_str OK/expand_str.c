#include <unistd.h>
#include <stdio.h>
int main(int ac, char **av)
{
	if(ac == 2)
	{
		int i = 0;
		while(av[1][i] == ' ' || av[1][i] == '\t')
			i++;
		int flag = 0;
		while(av[1][i])
		{
			if(av[1][i] == ' ')
				flag = 1;
			if(av[1][i] != ' ')
			{
				if(flag == 1)
					write(1, "   ", 3);
				flag = 0;
				write(1, &av[1][i], 1);
			}
			i++;
		}
	}
	write(1, "\n", 1);
	return (0);
}