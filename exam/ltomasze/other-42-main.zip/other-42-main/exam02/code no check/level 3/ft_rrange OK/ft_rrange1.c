#include <stdlib.h>
int ft_abs(int nbr)
{
	if(nbr < 0)
		return(-nbr);
	return(nbr);
}

int     *ft_rrange(int start, int end)
{
	int *tab = 0;
	int len = 0;
	if(start < end)
	{
		len = ft_abs(end - start) + 1;
		tab = (int *)malloc(sizeof(int) * len);
	}
	else
	{
		len = ft_abs(start - end) + 1;
		tab = (int *)malloc(sizeof(int) * len);
	}
	if(tab == NULL)
		return(0);
	int i = 0;
	tab[i] = end;
	while(start <= end)
		tab[i++] = end--;
	tab[i] = end;
	while(start >= end)
		tab[i++] = end++;
	return(tab);
}

#include<stdio.h>
int main()
{
	int start = 0;
	int end = -3;
	int len = ft_abs(start - end) + 1;
	int *tab = 0;
	tab = ft_rrange(start, end);
	int i = 0;
	while(i < len)
	{
		printf(" [%i] ", tab[i]);
		i++;
	}
	printf("\n");
}