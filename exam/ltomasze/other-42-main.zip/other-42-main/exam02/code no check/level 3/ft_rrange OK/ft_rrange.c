#include <stdlib.h>

int ft_abs(int nbr)
{
	if(nbr < 0)
		return(-nbr);
	return(nbr);
}

int     *ft_rrange(int start, int end)
{
	int *tab = 0;
	int len = 0;
	int i = 0;
	if(start > end)
	{
		len = ft_abs(start - end);
		tab = (int *)malloc(sizeof(int) * len + 1);
	}
	else
	{
		len = ft_abs(end - start);
		tab = (int *)malloc(sizeof(int) * len + 1);
	}
	if(tab == NULL)
		return (0);
	tab[i] = end;
	while(start <= end)
	{
		tab[i] = end;
		end--;
		i++;
	}
	tab[i] = end;
	while(start >= end)
	{
		tab[i] = end;
		end++;
		i++;
	}
	return(tab);
}

#include<stdio.h>
int main()
{
	int i = 0;
	int start = 0;
	int end = -3;
	int *tab;
	tab = ft_rrange(start, end);
	int len = ft_abs(end - start) + 1;
	while(i < len)
	{
		printf(" [%i] ", tab[i]);
		i++;
	}
	printf("\n");
}