#include<unistd.h>

int ft_atoi(char *nptr)
{
	int i = 0;
	int res = 0;
	while(nptr[i] != '\0')
	{
		res = res * 10 + nptr[i] - 48;
		i++;
	}
	return (res);
}

void	putnbr(int nbr)
{
	if(nbr > 9)
		putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int	prime(int p)
{
	int i = 2;
	if(p < 2)
		return (0);
	while(i * i <= p)
	{
		if(p % i == 0)
			return (0);
		i++;
	}
	return (1);
}

int	main(int ac, char **av)
{
	if(ac == 2 && ft_atoi(av[1]) > 0)
	{
		int n = ft_atoi(av[1]);
		int sum = 0;
		while(n > 1)
		{
			if(prime(n))
				sum += n;
			n--;
		}
		putnbr(sum);
		write(1, "\n", 1);
	}
	else
		write(1, "0\n", 2);
	return (0);
}

/*
#include<stdio.h>
int main()
{
	char *nptr = "50";
	int nbr = 50;
	int p = 5;
	printf("%d\n", ft_atoi(nptr));
	putnbr(nbr);
	printf("\n");
	printf("%d\n", prime(p));
}
*/