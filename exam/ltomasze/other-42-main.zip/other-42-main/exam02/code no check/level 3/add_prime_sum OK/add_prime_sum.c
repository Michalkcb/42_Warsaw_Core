#include <unistd.h>

int	ft_atoi(const	char *nptr)
{
	int	i = 0;
	int	res = 0;

	while(nptr[i] != '\0')
	{
		if(nptr[i] >= '0' && nptr[i] <= '9')
			res = res * 10 + nptr[i] - 48;
		i++;
	}
	return (res);
}

int is_prime(int nbr)
{
	if(nbr < 2)
		return (0);
	int	i = 2;
	while( i * i <= nbr)
	{
		if(nbr % i == 0)
			return(0);
		i++;			
	}
	return (1);
}

void ft_putnbr(int nbr)
{
	if(nbr > 9)
		ft_putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int	main(int ac, char **av)
{
	if (ac == 2)
	{
		int n = ft_atoi(av[1]);
		int sum = 0;
		while (n > 0)
		{
			if (is_prime(n))
				sum += n;
			n--;
		}
		ft_putnbr(sum);
		write(1, "\n", 1);
	}
	else
		{
			write(1, "0\n", 1);
		}
	
	return (0);
}