#include<unistd.h>
void putnbr(int nbr)
{
	if(nbr < 0)
	{
		write(1, "-", 1);
		putnbr(-nbr);
	}
	if(nbr > 9)
		putnbr(nbr / 10);
	write(1, &"0123456789"[nbr % 10], 1);
}

int main(int ac, char **av)
{
	if(ac != 1)
	{
		int i = 0;
		while(av[i])
			i++;
		putnbr(i - 1);
		write(1, "\n", 1);
	}
	else
		write(1, "0\n", 2);
}