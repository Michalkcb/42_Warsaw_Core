#include <stddef.h>
#include "ft_list.h"

int	ft_list_size(t_list *begin_list)
{
	int i = 0;
	while(begin_list != NULL)
	{
		begin_list = begin_list->next;
		i++;
	}
	return(i);
}

#include<stdio.h>
int main()
{
	t_list data3 = {NULL, "C"};
	t_list data2 = {&data3, "B"};
	t_list data1 = {&data2, "A"};
	printf("%i\n", ft_list_size(&data1));
}