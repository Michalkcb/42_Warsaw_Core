#include "ft_list.h"

int	ft_list_size(t_list *begin_list)
{
	int i = 0;
	while(begin_list)
	{
		begin_list = begin_list->next;
		i++;
	}
	return(i);
}

#include <stdio.h>
int main()
{
    t_list node3 = {NULL, "C"};
    t_list node2 = {&node3, "B"};
    t_list node1 = {&node2, "A"};

    printf("List size: %d\n", ft_list_size(&node1));

    return 0;
}