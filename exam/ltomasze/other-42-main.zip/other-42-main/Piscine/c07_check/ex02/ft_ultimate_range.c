/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/13 11:02:25 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/13 15:49:46 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	*t;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	t = malloc(sizeof(*t) * (max - min));
	if (t == NULL)
		return (-1);
	else
	{
		i = 0;
		while (max - min)
		{
			t[i] = min;
			min++;
			i++;
		}
		*range = t;
		return (i);
	}
}
/*
int main(void)
{
	int	min;
	int	max;
	int	*range;
	int	size;
	int	i;

	i = 0;
	min = 5;
	max = 10;
	size = ft_ultimate_range(&range, min, max);
	while(i < size)
	{
		printf("%d", range[i]);
		i++;
	}
}
*/
