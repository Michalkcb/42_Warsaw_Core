/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/12 16:57:41 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/12 18:22:52 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*t;
	int	i;

	i = 0;
	if (min >= max)
		return (NULL);
	t = (int *)malloc(sizeof(int) * (max - min));
	while (min < max)
	{
		t[i] = min;
		min++;
		i++;
	}
	return (t);
}
/*
int	main()
{
	int	min;
	int	max;
	int	*tab;
	int	i = 0;
	int	size;

	min = -4;
	max = 10;
	size = max - min;
	tab = ft_range(min, max);
	while(i < size)
	{
		printf("%d, ", tab[i]);
		i++;
	}
}
*/
