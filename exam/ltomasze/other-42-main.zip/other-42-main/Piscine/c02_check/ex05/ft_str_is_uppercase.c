/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/04 14:56:24 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/04 15:07:55 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			i++;
		else
		{
			return (0);
		}
	}
	return (1);
}
/*
int main()
{
	char	*t;
	char	*f;
	t = "ABCDEFG";
	f = "ABCdEFG";

	printf("%d", ft_str_is_uppercase(t));
	printf("\n%d", ft_str_is_uppercase(f));
}
*/
