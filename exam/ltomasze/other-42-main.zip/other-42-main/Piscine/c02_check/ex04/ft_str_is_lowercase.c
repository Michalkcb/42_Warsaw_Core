/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/04 14:39:40 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/04 14:53:08 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
			i++;
		else
		{
			return (0);
		}
	}
	return (1);
}
/*
int	main()
{
	char	*t;
	char	*f;

	t = "abcdefgh";
	f = "abcDefgh";
	printf("%d", ft_str_is_lowercase(t));
	printf("\n%d", ft_str_is_lowercase(f));
}
*/
