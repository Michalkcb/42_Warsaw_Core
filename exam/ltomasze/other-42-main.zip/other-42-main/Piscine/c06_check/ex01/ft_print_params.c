/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/10 18:32:55 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/10 20:03:12 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	main(int agrc, char *agrv[])
{
	int	i;
	int	j;

	i = 1;
	if (agrc > 1)
	{
		while (i < agrc)
		{
			j = 0;
			while (agrv[i][j] != '\0')
			{
				ft_putchar(agrv[i][j]);
				++j;
			}
			i++;
			ft_putchar('\n');
		}
	}
	return (0);
}
