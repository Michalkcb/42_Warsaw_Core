/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/10 20:31:23 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/10 20:46:02 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	main(int agrc, char **agrv)
{
	int	i;
	int	j;

	i = agrc - 1;
	while (i > 0)
	{
		j = 0;
		while (agrv[i][j] != '\0')
		{
			ft_putchar(agrv[i][j]);
			++j;
		}
		i--;
		ft_putchar('\n');
	}
	return (0);
}
