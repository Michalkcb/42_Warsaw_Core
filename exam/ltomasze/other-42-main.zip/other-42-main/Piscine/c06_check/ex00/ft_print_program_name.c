/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/10 15:34:53 by ltomasze          #+#    #+#             */
/*   Updated: 2023/12/10 18:25:48 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	main(int agrc, char **agrv)
{
	int	i;

	(void) agrc;
	i = 0;
	while (agrv[0][i] != '\0')
	{
		ft_putchar(agrv[0][i]);
		++i;
	}
	ft_putchar('\n');
	return (0);
}
