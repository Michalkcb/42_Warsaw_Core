/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ltomasze <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/28 11:00:08 by ltomasze          #+#    #+#             */
/*   Updated: 2023/11/28 12:50:31 by ltomasze         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
/*
int	main()
{
	int i;
	int *i1;
       	int **i2;
       	int ***i3;
       	int ****i4;
       	int *****i5;
       	int ******i6;
       	int *******i7;
       	int ********i8;
       	int *********i9;

	i = 4;
	i1 = &i;
	i2 = &i1;
	i3 = &i2;
	i4 = &i3;
	i5 = &i4;
	i6 = &i5;
	i7 = &i6;
	i8 = &i7;
	i9 = &i8;

	printf("before: %d\n", i);
	ft_ultimate_ft(i9);
	printf("after: %d\n", i);
}
*/
